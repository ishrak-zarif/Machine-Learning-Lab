import sklearn as sk

"""
The task is pretty simple here. Apply your machine learning methods and analyze the results. 
You must produce the final output as "training_labels.txt" for the input "training_data.txt" and save the output as "testing_labels.txt"

Thank you for your effort. 

Deadline: 30th December,2017.

Submission Procedure: 1 week before deadline, you will have A goodgle Drive access to upload your assignment.

Do not forget to write  your roll number somewhere I find easily.

For any further question, send an email to; bishnukuet@gmail.com

Thank you.
"""



#TODO: Write your code here.


if __name__ == '__main__':
    pass
